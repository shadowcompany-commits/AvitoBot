def generate_text():
    return 'Текст объявления'