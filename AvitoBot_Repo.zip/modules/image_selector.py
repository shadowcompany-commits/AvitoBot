def select_image():
    return 'image.jpg'